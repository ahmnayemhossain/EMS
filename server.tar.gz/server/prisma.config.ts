import "dotenv/config";
import { defineConfig, env } from "prisma/config";

export default defineConfig({
  schema: "prisma/schema.prisma",
  migrations: {
    path: "prisma/migrations",
    seed: "node src/scripts/seed-defaults.js",
  },
  datasource: {
    url: env("DATABASE_URL"),
  },
});
